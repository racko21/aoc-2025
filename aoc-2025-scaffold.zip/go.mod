module github.com/yourusername/aoc-2025

go 1.23
